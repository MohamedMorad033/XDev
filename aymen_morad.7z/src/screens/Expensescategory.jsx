import React, { useEffect, useState } from 'react'
import { DataGrid } from '@mui/x-data-grid';
import axios from 'axios';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import MenuItem from '@mui/material/MenuItem'
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import Select from '@mui/material/Select'
import InputLabel from '@mui/material/InputLabel'
import InputAdornment from '@mui/material/InputAdornment'
import { Checkbox, Overlay } from '@blueprintjs/core';
import Refresh from '@mui/icons-material/RefreshRounded'

import DataTable, { createTheme } from 'react-data-table-component';
createTheme('solarized', {
    text: {
      primary: '#fff',
      secondary: '#eee',
    },
    background: {
      default: '#161b22',
    },
    context: {
      background: 'rgba(0,0,0,0.9)',

      text: '#FFFFFF',
    },
    divider: {
      default: '#424242',
    },
    action: {
      button: 'rgba(0,0,0,.54)',
      hover: 'rgba(0,0,0,.08)',
      disabled: 'rgba(0,0,0,.12)',
    },
  }, 'dark');
  
const mesures = [
    {
        value: 'seller',
        label: 'مورد',
    },
    {
        value: 'buyer',
        label: 'عميل',
    },
    {
        value: 'both',
        label: 'عميل و مورد',
    },
];
const ExpandedComponent = ({ data }) => <pre>{JSON.stringify(data, null, 2)}</pre>;

function Expensescategory() {

    const [rows, setrows] = useState([
    ]);
    const [editrn, seteditrn] = useState(false)
    const [selected, setelected] = useState(
    )
    const columns = [
        {
            name: 'كود',
            selector: row => row.id,
            sortable: true,
        },
        {
            name: 'الاسم',
            selector: row => row.name,
            sortable: true,
            size: 20
        }
    ];


    useEffect(() => {
        axios.get('http://localhost:1024/Expensescategory').then((resp) => {
            setrows(resp.data.Expensescategorys);
        })
    }, [])
    const [sel, setsel] = useState('seller')
    const [name, setname] = useState('')
    const [expenses, setexpenses] = useState('')
    const [payments, setpayments] = useState('')
    const [code, setcode] = useState()
    const [selid, setselid] = useState()
    const [loadrn, setloadrn] = useState(false)




    const [newsel, setnewsel] = useState('seller')
    const [newname, setnewname] = useState('')
    const [newexpenses, setnewexpenses] = useState('0')
    const [newpayments, setnewpayments] = useState('0')
    const [newcode, setnewcode] = useState()
    const [newselid, setnewselid] = useState()
    const [newloadrn, setnewloadrn] = useState(false)
    const [searchload, setsearchload] = useState(false)
    const [searchtext, setsearchtext] = useState('')


    const editsubmit = () => {
        setloadrn(true)
        axios.post('http://localhost:1024/editExpensescategory', { name, selid }).then((resp) => {
            if (resp.data.status == 200) {
                console.log(resp.data)
                setrows([])
                setloadrn(false)
                seteditrn(false)
                axios.get('http://localhost:1024/Expensescategory').then((resp) => { setrows(resp.data.Expensescategorys) })
            } else {
                setloadrn(false)
                alert('failed')
            }
        })
    }
    const createnew = () => {
        if (!newname) {
            alert('name cannot be empty')
            return
        }
        setloadrn(true)
        axios.post('http://localhost:1024/addExpensescategory', { name: newname, expenses: newexpenses, payments: newpayments, code: newcode, selectmode: newsel }).then((resp) => {
            if (resp.data.status == 200) {
                console.log(resp.data)
                setrows([])
                setloadrn(false)
                seteditrn(false)
                setnewcode(newcode + 1)
                axios.get('http://localhost:1024/Expensescategory').then((resp) => { setrows(resp.data.Expensescategorys) })
            } else {
                setloadrn(false)
                alert('failed')
            }
        })
    }



    const search = (text) => {
        setsearchload(true)
        axios.post('http://localhost:1024/searchExpensescategory', { searchtext: text }).then((resp) => {
            if (resp.data.status == 200) {
                setsearchload(false)
                console.log(resp.data)
                setrows([])
                setrows(resp.data.foundproduts)
            } else {
                setloadrn(false)
                alert('failed')
                setsearchload(false)
                axios.get('http://localhost:1024/Expensescategory').then((resp) => { setrows(resp.data.Expensescategorys) })

            }
        })
    }
    const [refreshloading, setrefreshloading] = useState(false)
    return (
        <div style={{ width: '100%' }}>
            <div style={{ width: '100%', alignItems: 'center', display: 'flex', justifyContent: 'start', flexDirection: 'row' }}>

                <TextField
                    style={{ marginRight: 20 , marginLeft : 20 }}
                    autoFocus
                    margin="dense"
                    id="name"
                    size='small'

                    label="اسم الصنف"
                    type="text"
                    value={newname}
                    onChange={(e) => { setnewname(e.currentTarget.value) }}
                    variant="outlined"
                />
                <Button size='medium'
                    disabled={newloadrn} variant='contained' onClick={() => { createnew() }}>Create</Button>

            </div>
            <div style={{ width: '100%', display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
                <div style={{ display: 'flex', alignItems: 'baseline' }}>
                    <TextField
                        style={{ marginLeft: 20 }}
                        autoFocus
                        margin="dense"
                        id="search"
                        label="search"
                        type="text"
                        value={searchtext}
                        onChange={(e) => { setsearchtext(e.target.value); search(e.target.value) }}
                        variant="standard"
                    />
                    <Button style={{ height: 30, marginLeft: 20 }} disabled={searchload} variant='contained' color='error' onClick={() => {
                        setsearchtext(''); axios.get('http://localhost:1024/Expensescategory').then((resp) => { setrows(resp.data.Expensescategorys) })
                    }}>Clear</Button>
                </div>
                <div>
                    <Button style={{ height: 30, marginRight: 20 }} disabled={refreshloading} variant='contained' color='warning' onClick={() => {
                        setrefreshloading(true);
                        axios.get('http://localhost:1024/Expensescategory').then((resp) => { setrows(resp.data.Expensescategorys); setrefreshloading(false) })
                    }} endIcon={<Refresh />}>Refresh</Button>
                </div>
            </div>
            <div style={{ width: '100%' }}>
                <DataTable
                    theme='solarized'
                    pagination
                    selectableRowsComponent={Checkbox}
                    columns={columns}
                    data={rows}
                    onRowDoubleClicked={(data) => { seteditrn(true); setname(data.name); setselid(data.id) }}
                    expandableRows
                    expandableRowsComponent={ExpandedComponent}
                />
            </div>
            <Dialog open={editrn}>
                <DialogTitle>Edit A Client</DialogTitle>
                <DialogContent>
                    <TextField
                        autoFocus
                        margin="dense"
                        id="name"
                        label="الاسم"
                        type="text"
                        value={name}
                        onChange={(e) => { setname(e.currentTarget.value) }}
                        fullWidth
                        variant="standard"
                    />
                </DialogContent>
                <DialogActions>
                    <Button onClick={() => { seteditrn(false) }} >الغاء</Button>
                    <Button disabled={loadrn} variant='contained' onClick={() => { editsubmit() }}>حفظ</Button>
                </DialogActions>
            </Dialog>
        </div>

    )
}

export default Expensescategory