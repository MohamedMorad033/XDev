import { useState } from 'react';
import './App.css';
import '@fontsource/roboto/300.css';
import '@fontsource/roboto/400.css';
import '@fontsource/roboto/500.css';
import '@fontsource/roboto/700.css';
import Products from "./screens/products"
import { BrowserRouter as Router, Routes, Route, Link, Outlet } from 'react-router-dom';
import axios from 'axios';
import logo from './static/b2b.png'
import Clients from './screens/Clients';
import Vault from './screens/vault';
import Transactions from './screens/Transactions';
import Expenses from './screens/Expenses';
import Expensescategory from './screens/Expensescategory';
import Expensescategory2 from './screens/Expensescategory2';
import Pincome from './screens/Pincome';
import Vctransaction from './screens/Vctransaction';
import ProductHistory from './screens/ProductHistory';
import Poutcome from './screens/poutcome';
import Workers from './screens/Workers';
import WorkerPayout from './screens/WorkerPayout';
import Fridge from './screens/Fridge';
import FridgeIncome from './screens/FridgeIncome';
import {
  Alignment,
  Button,
  Classes,
  H5,
  Navbar,
  NavbarDivider,
  NavbarGroup,
  NavbarHeading,
  Switch,
} from "@blueprintjs/core";
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import Workertransaction from './screens/Workertransaction';
import Moneyowners from './screens/Moneyowners';
import Moneyownertransactions from './screens/Moneyownertransactions';
import Productexport from './screens/Productexport';
import PropTypes from 'prop-types';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import Productimport from './screens/Productimport';
import Plink from './screens/Plink';
import Finalimport from './screens/Finalimport';
import Summery from './screens/Summery';
const darkTheme = createTheme({
  palette: {
    mode: 'dark',
  },
});




function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <div style={{ width: '100%' }}>
          {children}
        </div>
      )}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  };
}



function App() {
  const [value, setValue] = useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <ThemeProvider theme={darkTheme}>
      <header className="App-header">
        <div style={{ width: '100%' }}>
          <Box sx={{ borderBottom: 1, borderColor: 'divider' , display : 'flex' , flexDirection : 'row'}}>
            <img onClick={(e) => {
              e.preventDefault();
              window.location.href = 'http://localhost:3000/';
            }} src={logo} width={65.61} height={40} style={{ margin: 5 }} />

            <Tabs variant="scrollable" scrollButtons='auto' allowScrollButtonsMobile value={value} onChange={handleChange} aria-label="basic tabs example">
              <Tab wrapped label="الاصناف" {...a11yProps(0)} />
              <Tab wrapped label="العملاء والموردين" {...a11yProps(1)} />
              <Tab wrapped label="الشركاء" {...a11yProps(2)} />
              <Tab wrapped label="ايرادات الشركاء" {...a11yProps(3)} />
              <Tab wrapped label="الخزن" {...a11yProps(4)} />
              <Tab wrapped label="التحويلات" {...a11yProps(5)} />
              <Tab wrapped label="اصناف المصروفات" {...a11yProps(6)} />
              <Tab wrapped label="اصناف اصناف المصروفات" {...a11yProps(7)} />
              <Tab wrapped label="المصروفات" {...a11yProps(8)} />
              <Tab wrapped label="استلام المخزن" {...a11yProps(9)} />
              <Tab wrapped label="ايرادات وصادرات الخزنه" {...a11yProps(10)} />
              <Tab wrapped label="جرد المخزن" {...a11yProps(11)} />
              <Tab wrapped label="تصدير منتج" {...a11yProps(12)} />
              <Tab wrapped label="استلام منتج" {...a11yProps(13)} />
              <Tab wrapped label="صادرات المخزن" {...a11yProps(14)} />
              <Tab wrapped label="المقاولين" {...a11yProps(25)} />
              <Tab wrapped label="اليوميات" {...a11yProps(16)} />
              <Tab wrapped label="الراتب" {...a11yProps(17)} />
              <Tab wrapped label="ربط الاصناف" {...a11yProps(18)} />
              <Tab wrapped label="الثلاجه" {...a11yProps(19)} />
              <Tab wrapped label="استلام الثلاجه" {...a11yProps(20)} />
              <Tab wrapped label="استلام منتج نهائي" {...a11yProps(21)} />
              <Tab wrapped label="تقارير العملاء والاصناف" {...a11yProps(22)} />
            </Tabs>
          </Box>
          <TabPanel value={value} index={0}>
            <Products />
          </TabPanel>
          <TabPanel value={value} index={1}>
            <Clients />
          </TabPanel>
          <TabPanel value={value} index={2}>
            <Moneyowners />
          </TabPanel>
          <TabPanel value={value} index={3}>
            <Moneyownertransactions />
          </TabPanel>
          <TabPanel value={value} index={4}>
            <Vault />
          </TabPanel>
          <TabPanel value={value} index={5}>
            <Transactions />
          </TabPanel>
          <TabPanel value={value} index={6}>
            <Expensescategory />
          </TabPanel>
          <TabPanel value={value} index={7}>
            <Expensescategory2 />
          </TabPanel>
          <TabPanel value={value} index={8}>
            <Expenses />
          </TabPanel>
          <TabPanel value={value} index={9}>
            <Pincome />
          </TabPanel>
          <TabPanel value={value} index={10}>
            <Vctransaction />
          </TabPanel>
          <TabPanel value={value} index={11}>
            <ProductHistory />
          </TabPanel>
          <TabPanel value={value} index={12}>
            <Productexport />
          </TabPanel>
          <TabPanel value={value} index={13}>
            <Productimport />
          </TabPanel>
          <TabPanel value={value} index={14}>
            <Poutcome />
          </TabPanel>
          <TabPanel value={value} index={15}>
            <Workers />
          </TabPanel>
          <TabPanel value={value} index={16}>
            <WorkerPayout />
          </TabPanel>
          <TabPanel value={value} index={17}>
            <Workertransaction />
          </TabPanel>
          <TabPanel value={value} index={18}>
            <Plink />
          </TabPanel>
          <TabPanel value={value} index={19}>
            <Fridge />
          </TabPanel>
          <TabPanel value={value} index={20}>
            <FridgeIncome />
          </TabPanel>
          <TabPanel value={value} index={21}>
            <Finalimport />
          </TabPanel>
          <TabPanel value={value} index={22}>
            <Summery />
          </TabPanel>

        </div>
      </header>
    </ThemeProvider>
  );
}

export default App;
